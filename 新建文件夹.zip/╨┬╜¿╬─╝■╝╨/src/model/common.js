var common = {
  //获取微信登录openid
  'get_session_key': {
    'api': 'get_session_key',
    'auth': false,
    'method': 'POST'
  },

  //用户激活
  'go_login': {
    'api': 'userAct',
    'auth': false,
    'method': 'POST'
  },

  //获取手机验证码
  'get_phone_code' : {
    'api' : 'codes',
    'auth' : false,
    'method' : 'POST'
  },

  //首页轮播图接口
  'get_advs': {
    'api': 'cms/advs',
    'auth': false,
    'method': 'GET'
  },

  //获取用户详情 domain
  'get_user_domain' : {
    'api' : 'pages/page/getDetailByUser',
    'auth' : true,
    'method' : 'GET'
  },

  //获取用户微友 关注 粉丝等数据
  'get_user_friends' : {
    'api' : 'circel/index',
    'auth' : true,
    'method' : 'GET'
  }
};
export default common;
