import wepy from 'wepy';
import ajax from '../utils/ajax';
//业务相关接口
import news from '../model/news'; //新闻模块接口
import activity from '../model/activity'; //活动模块接口
import join from '../model/join'; //加入商会模块接口
import common from '../model/common'; //公共接口

let model={};
model.apiUrl = {
  'common': common,
  'news' : news,
  'activity' : activity,
  'join': join
};
model.login = async(obj) => {
  const userInfo = wepy.getStorageSync('userInfo');
  console.log('init-userInfo',userInfo);
  if(!userInfo || userInfo.expires_time < (Date.now() + 600) || obj){
    console.log('需要重新登录');
    var login = await wepy.login();
    var getOpenId = await model.init('common.get_session_key',{'js_code': login.code});
    wepy.setStorageSync('userInfo' , getOpenId.data);
    console.log('after-login-userinfo',getOpenId.data);
    if(obj){
      await model.init(obj.action, obj.param)
    }
  }
};
model.toLogin = function () {
    console.log('需要激活');
    wx.redirectTo({
      url: '/pages/login'
    });
    return
};
model.init = async(action, param) => {
  let apiArr = action.split('.');
  let apiInfo = model.apiUrl[apiArr[0]][apiArr[1]];
  if(apiInfo.auth){
    await model.login();
    var getUserInfo = wepy.getStorageSync('userInfo');
    if(!getUserInfo.user_info){
      await model.toLogin();
    }
  }
  let res = await ajax.method(apiInfo.method, apiInfo.api, param);
  if(res.data.uptoken){
    return res.data;
  }
  switch (res.data.code){
    case 200:
      return res.data;
    case 401:
      //重新登录 并且再次重发一遍请求
      await model.login({'action':action, 'param': param});
    case -200:
      wepy.showToast({
        title: res.data.message,
        icon: "none"
      });
      break;
  }
};

module.exports = model;

