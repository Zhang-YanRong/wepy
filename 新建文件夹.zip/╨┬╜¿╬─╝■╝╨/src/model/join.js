var join = {
  //会员初始信息（加入商会初始判断条件1）
  'member_setting': {
    api: 'member/setting',
    method: 'GET',
    auth: true
  },

  //查看微主页开通情况(加入商会初始判断条件2)
  'get_page_info': {
    api: 'pages/page/info',
    method: 'GET',
    auth: true
  },

  //实名认证详情信息
  'get_realNameCert_detail': {
    api: 'cert/realName/detail',
    method: 'GET',
    auth: true
  },

  //判断官方认证下的人工认证和机构认证是否开启
  'get_officalCert_type': {
    api: 'cert/ofccerts',
    method: 'GET',
    auth: true
  },

  //实名认证信息提交
  'submit_realNameCert': {
    api: 'cert/realName',
    method: 'POST',
    auth: true
  },

  //实名认证信息修改
  'modify_realNameCert': {
    api: 'cert/realName/update',
    method: 'POST',
    auth: true
  },

  //官方认证信息提交
  'submit_ofcerts': {
    api: 'cert/ofccerts',
    method: 'POST',
    auth: true
  },

  //官方认证信息提交
  'modify_ofcerts': {
    api: 'cert/ofccerts',
    method: 'PUT',
    auth: true
  },

  //获取会员等级信息
  'get_member_type': {
    api: '/member/session/current',
    mehtod: 'GET',
    auth: true
  },

  //会员提交详情信息
  'member_apply_detail': {
    api: 'member/apply',
    method: 'GET',
    auth: true
  },

  //会员提交
  'member_apply_submit': {
    api: 'member/apply',
    method: 'POST',
    auth: true
  },

  //会员修改
  'member_apply_modify': {
    api: 'member/apply',
    method: 'PUT',
    auth: true
  }

}
export default join;
