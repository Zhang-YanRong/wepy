const news = {
  //查询新闻模块的所有分类
  'get_news_category': {
    'api': 'cms/channel_categories',
    'method': 'GET',
    'auth': false
  },

  //查询新闻的一些特别分类（推荐新闻/精选内容）
  'get_news_other': {
    'api': 'cms/contents',
    'method': 'GET',
    'auth': false
  },

  //新闻频道接口
  'get_cms_news': {
    'api': 'cms/contents',
    'method': 'GET',
    'auth': false
  },

  //新闻列表分类
  'news_category_list': {
    'api': 'cms/index/list_news_by_channel',
    'method': 'GET',
    'auth': false
  },

  //新闻详情页
  'news_category_list_content': {
    'api': 'cms/detail',
    'method': 'GET',
    'auth': false
  },

  //新闻更多列表页 title
  'cate_tree_by_channel':{
    'api': 'cms/cate_tree_by_channel',
    'method': 'GET',
    'auth': false
  }
};

export default news;
