const activity = {
  //获取活动分类接口
  'get_activity_category': {
    'api': 'activity/cate/lists',
    'method': 'GET',
    'auth': false
  },

  //获取活动列表
  'get_activity_list': {
    'api': 'activity/lists',
    'method': 'GET',
    'auth': false
  },

  //活动详情接口
  'get_activity_detail': {
    'api': 'activity/detail',
    'method': 'GET',
    'auth': false
  },

  //活动嘉宾列表
  'get_activity_guest': {
    'api': 'activity/guest/lists',
    'method': 'POST',
    'auth': false
  },

  //获取七牛token
  'get_qiniu_token': {
    'api': 'file/qiniu_token',
    'method': 'GET',
    'auth': false
  },

  //获取单个活动票的种类
  'get_activity_ticket': {
    'api': 'activity/tickets',
    'method': 'GET',
    'auth': false
  },

  //提交报名信息
  'send_enroll_form': {
    'api': 'activity/enroll/store',
    'method': 'POST',
    'auth': true
  },

  //获取用户所有报名的活动列表
  'get_user_enroll_activity': {
    'api': 'activity/enroll/my_enrolls',
    'method': 'GET',
    'auth': true
  },

  //已报名的活动详情
  'get_enroll_act_detail': {
    'api': 'activity/enroll/detail',
    'method': 'GET',
    'auth': true
  },

  //判断活动状态请求
  'get_act_status': {
    'api': 'activity/enroll_my_order',
    'method': 'POST',
    'auth': true
  },

  //活动报名支付接口
  'get_act_pay_config': {
    'api': 'pages/wechatpay/enroll_order_phone_pay',
    'method': 'POST',
    'auth': true
  }

};
export default activity
