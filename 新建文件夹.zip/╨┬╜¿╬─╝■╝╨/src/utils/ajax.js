import wepy from 'wepy';
import app from '@/utils/app';
let ajax = {};
let api = 'https://m.dev.wezchina.com/api/';
let header = {'Content-Type': 'application/json'};
ajax.method = async(method, url, param) => {
  try{
    let apiUrl = api+url;

    //如果链接需要拼接url
    if(param && param.apiUrlSuffix){
      apiUrl = apiUrl + '/' + param.apiUrlSuffix;
    }

    //根据用户信息加上token头
    const userInfo = wepy.getStorageSync('userInfo').user_info;
    if(userInfo && !app.empty(userInfo)){
      header['Token'] = userInfo.token
    }

    let res = await wepy.request({
      url : apiUrl,
      method : method,
      data : param && !param.apiUrlSuffix ? param : {},
      header : header
    });

    return res

  }catch(e){
    console.log(e)
  }
};
export default ajax;
