let app = {};
app.empty = (obj) => {
  if(typeof(obj) == 'object'){
    return !Object.keys(obj).length
  }
  return true
}

export default app;
